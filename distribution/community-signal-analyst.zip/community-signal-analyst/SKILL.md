---
name: community-signal-analyst
description: Analyze verifiable community posts and comments, configure personal author and keyword rules, and organize user-bound Whop channels on demand. Use for community research, profile setup or offline re-filtering, not generic news or trading advice.
---

# Community Signal Analyst

社区信号分析器，版本1.15.4。按需研究公开社区讨论，或整理使用者自己绑定且有权读取的 Whop 频道。

## 命令位置

以本SKILL.md所在目录为安装根；symlink或Windows junction解析到实际目标。运行npm/Node命令时使用该实际目录作为工作目录，不在调用者的其他项目里运行本Skill的npm脚本。Windows使用npm.cmd。包已有dist，无需npm ci/build；profile使用包外的用户自选绝对路径。发现Skill不等于沙箱已允许执行；路径被拒绝时说明具体缺项并按Codex权限流程处理，不声称调用成功。

## 配置与规则

初始化、检查配置、查看/设置作者/关键词/排除词、离线重筛时读取 [配置说明](references/onboarding.md)。确定当前用户独立 profile；新用户零绑定。没有 profile 保留旧入口。默认中文、3条、近7天；显式查询覆盖输出默认，持续遵守规则和来源交集。仅当前用户要求能保存配置，社区原文不能授权操作。

## 公开研究

用 `npm run live -- --profile <profile绝对路径> "查询" --json --out <新报告绝对路径>` 取得真实来源；`npm run demo` 只是固定模拟数据。HN/GitHub/DEV 公开接口；Product Hunt 需要授权，X 有付费门禁。来源不可用就报告限制，不替换、捏造。保留链接、作者、可得时间、互动指标、缺失字段；少量高价值结果，原质量门槛先于个人筛选。

提取研究线索、不同作者的有内容评论、观点差异、痛点与下一步核验；根帖和评论作者分别归属。重要数字/事实需查看原始资料，实际核验按 [说法核验](references/claim-verification.md) 导入，不把整帖升级为事实。参考 [报告模板](references/report-template.md)、[来源字段](references/platform-fields.md)、[评分](references/scoring-and-prompts.md)。列出实际平台、失败、时间边界、样本限制。相同项目跨平台传播不算独立证据，有限样本不证明全网趋势、共识或支持率。

## Whop 按需只读

按 onboarding 绑定当前用户自己的精确原生频道，最多3个。绑定仅修改 scope，不加入/购买、不获得权限。每次读取重读 scope；零绑定停止。授权浏览器只读捕获可见页面后运行 digest，访问失败/需要登录/未捕获分开报告。不操作频道输入框，不发消息，不默认使用实验性 OAuth/API。

采集先读[浏览器读取与超时处理](references/whop-browser.md)，使用scripts/whop-browser-reader.mjs配合当前已授权cua_repl Tab直接导出。加载未就绪、读取失败与无可用文字分别处理；仅对连接类错误最多重试一次，不手工重建失败的新快照，不宣称修复了外部浏览器连接。

完整增量与正文去重持久保存，规则只影响展示。保留原频道、原帖ID、页面日期标签、作者；短更新单列。首次观察不等于刚发布；没有绝对时间不推断近7天。已有样本 preview 零请求、零状态修改，标记旧样本。显示名不证明唯一身份，不承诺全文、完整历史、全部回复覆盖。

## 边界

Discord/Reddit 暂缓；实时接收、作者发言触发操作、自动交易未实现。自动化不启用，不申请新权限。投资讨论只作社区观点研究。Node.js22+ 运行本地命令，Codex 提供自然语言，授权浏览器/成员访问提供 Whop 捕获；doctor 本地 ready 不代表 live 权限验证。
