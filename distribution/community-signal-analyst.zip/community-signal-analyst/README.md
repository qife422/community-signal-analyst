# Community Signal Analyst

版本 1.15.0。需要 Node.js22+；已编译本地命令无需安装依赖。自然语言需 Codex，Whop 捕获需自己的授权浏览器/会员访问。

从 [首次配置说明](references/onboarding.md) 开始，创建包外独立 profile，零绑定。doctor 不验证在线权限；个人文件不属于分发内容。

manifest.json 保存全部负载文件字节数与 SHA-256，不含清单自身。开发者重建需 npm ci，再 npm run build。
